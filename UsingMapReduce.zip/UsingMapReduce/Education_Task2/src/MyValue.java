import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable{
	Text ww;
	
	public MyValue(){
		this.ww = new Text();
	}
	public MyValue(Text ww){
		this.ww = ww;
	};
	
	@Override
	public void readFields(DataInput arg0) throws IOException {
		ww.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		ww.write(arg0);
	}
	
	public void setww(Text ww){
		this.ww=ww;
	}
	public int getAmt(){
		return Integer.parseInt(ww.toString());
	}

}