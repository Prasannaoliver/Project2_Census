import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {
	public static void main(String[] args) throws IOException, URISyntaxException, ClassNotFoundException, InterruptedException{
		Configuration c = new Configuration();
		Job j = new Job(c,"Census Sex Ratio");
		j.setJarByClass(MyDriver.class);
		j.setMapperClass(MyMapper.class);
		j.setReducerClass(MyReducer.class);
		j.setPartitionerClass(MyPartitioner.class);
		j.setNumReduceTasks(6);
		j.setMapOutputKeyClass(Text.class);
		j.setMapOutputValueClass(Text.class);
		
		FileInputFormat.addInputPath(j,new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path(args[1]));
		
		try {
			DistributedCache.addCacheFile(new URI("/Oliver/agegroup1.dat"),j.getConfiguration());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		System.exit(j.waitForCompletion(true)?0:1);
	}

}
