
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;


public class MyMapper extends Mapper<MyKey, MyValue, Text, Text> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		String ucode = c.getConfiguration().get("c","30");
		String ccode = inpK.getCode();
		String g=inpV.getGrade().toString();
		if(ucode.trim().equals(ccode.trim())){
			c.write(new Text(ccode),new Text(g));
		}
	}
}

